﻿using UnityEngine;

public class ItemID : MonoBehaviour
{
    public int _itemID; // 현재 오브젝트가 가지고있는 _itemID 
    // 추후에 아이템이 다 만들어진다면 public 을 뺄계획
}
