using UnityEngine;

[CreateAssetMenu(menuName = "ScriptableObject / Item / Potion")]
public class Potion_Data : Item_Data
{
}
