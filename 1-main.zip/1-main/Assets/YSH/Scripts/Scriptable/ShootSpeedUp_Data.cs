using UnityEngine;

[CreateAssetMenu(menuName = "ScriptableObject / Item / ShootSpeedUp")]
public class ShootSpeedUp_Data : Item_Data
{

}
