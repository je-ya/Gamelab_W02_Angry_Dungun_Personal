using UnityEngine;
[CreateAssetMenu(menuName = "ScriptableObject / Item / SpeedUp")]
public class SpeedUp_Data : Item_Data
{

}
