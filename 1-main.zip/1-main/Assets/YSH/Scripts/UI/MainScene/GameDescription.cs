using UnityEngine;

public class GameDescription : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
